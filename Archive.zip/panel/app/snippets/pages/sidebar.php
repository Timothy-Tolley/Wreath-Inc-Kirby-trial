<aside class="sidebar">

  <a class="sidebar-toggle" href="#sidebar" data-hide="<?php _l('options.hide') ?>"><span><?php _l('options.show') ?></span></a>

  <div class="sidebar-content section">

    <?php echo $menu ?>
    <?php echo $subpages ?>
    <?php echo $files ?>

  </div>

</aside>