<?php if(!defined('KIRBY')) exit ?>

title: Default Page
pages: true
files: true
fields:
  title:
    label: Title
    type:  text
  text:
    label: Text
    type:  textarea