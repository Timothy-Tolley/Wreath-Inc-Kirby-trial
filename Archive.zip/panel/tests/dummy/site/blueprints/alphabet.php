<?php if(!defined('KIRBY')) exit ?>

title: Alphabet
pages: 
  template: char
  num: zero
files: false
fields:
  title:
    label: Title
    type:  text
