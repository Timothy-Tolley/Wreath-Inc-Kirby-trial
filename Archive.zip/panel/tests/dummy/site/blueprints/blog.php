<?php if(!defined('KIRBY')) exit ?>

title: Blog
pages: 
  template: article
  num: date
files: false
fields:
  title:
    label: Title
    type:  text
