<?php if(!defined('KIRBY')) exit ?>

username: test
email: test@getkirby.com
password: >
  $2a$10$kpBxQZ4Ib4hCLGDa7T3GYOpdR1JdB7dA2yXBorVJJrjBE8MRs.hQy
language: en
role: admin
firstname: Test
lastname: User